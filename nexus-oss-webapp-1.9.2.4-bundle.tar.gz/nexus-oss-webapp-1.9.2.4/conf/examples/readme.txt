Instructions for setup and use of these examples can be found at:
https://docs.sonatype.com/display/NX/Jetty+Configuration